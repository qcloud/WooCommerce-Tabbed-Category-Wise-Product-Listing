WooCommerce-Tabbed-Category-Wise-Product-Listing
================================================

WordPress WooCommerce Tabbed Category Wise Product Listing



#Description:

Have you ever tried a Woo-Commerce plugin that allow you to view products category wise ?
Woo-Product-Cat is a woocommerce plugin that allow you to achieve this result in the most easiest way.


Woo-Product-Cat is fully responsive and can fit any of your WordPress theme with a minimal css override.


#Installation:

1. Upload the zip file named woo-cat-product.zip in you wp-content/plugins folder.
2. Extract the zip file.
3. From the wp-admin panel goto plugins and activate "WooCommerce Category Product"
4. The plugin is fully dependent on WooCommerce. So WooCommerce must be installed and activated before using this plugin.
5. You are done.


#Use:

1. After activate the plugin, create a new page or post. In the body section write this shortcode [product-cat].
   Save the page/post and check the link. You'll see a nicely designed category wise product listing.